from django.urls import path
from . import views
app_name='products'
urlpatterns = [
    path('', views.index, name='index'),
    path('addcart', views.addcart, name='addcart'),
    # path('payment', views.Cart, name='pay'),
    path('order', views.order, name='order'),
    path('checkout', views.Checkout, name='checkout'),
    path('cart', views.CartList.as_view(), name='cart'),
    path('delete/<int:pk>', views.TodoDeleteView.as_view(), name='delete') ,
]