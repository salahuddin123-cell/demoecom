from django.db import models
from django.db.models.fields import NullBooleanField

# Create your models here.
class Product(models.Model):
    title=models.TextField(max_length=100,null=True)
    thumb=models.ImageField(blank=True,null=True)
    detail=models.TextField(null=True)
    price=models.PositiveIntegerField(null=True)
    def __str__(self):
        return self.title

class Addcart(models.Model):
    title=models.TextField(null=True)

    price=models.IntegerField(null=True)
    class Meta:
        ordering=['-pk']

class Order(models.Model):
    
    name=models.TextField(max_length=100,default='',blank=True)
    address=models.TextField(max_length=200, default='',blank=True)
    city=models.TextField(max_length=100, default='',blank=True)
    zip=models.PositiveIntegerField(null=True)
    phone=models.PositiveIntegerField(null=True)
    total=models.IntegerField(blank=True,default=200)
    items=models.TextField(max_length=1000,null=True)
    def __str__(self):
        return self.name