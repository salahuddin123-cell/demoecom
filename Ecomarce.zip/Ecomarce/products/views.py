from typing import List
from django.http.response import HttpResponse
import requests
from requests.api import request
from requests.sessions import Request
from ecomarce.settings import RAZORPAY_API_KEY, RAZORPAY_API_SECRET_KEY
from django.db import models
from django.contrib import messages
# from .forms import OrderCreate

from django.shortcuts import redirect, render
from django.views.generic import (View,TemplateView,
                                ListView,DetailView,
                                CreateView,DeleteView,
                                UpdateView, detail)
from .models import Product,Addcart,Order
from django.urls import reverse_lazy
import razorpay
# Create your views here.
# class IndexView(TemplateView):
#     model=Product
    
#     template_name='index.html'
def index(request):
    product_list=Product.objects.all()
    return render(request,'index.html',{'product_list':product_list})

def addcart(request):
    context={'success':False} 
    product_list=Product.objects.all()
    
    if request.method=='POST':
        
        name=request.POST.get('name') 

        price=request.POST.get('price')
        addcart=Addcart(title=name,price=price)

        addcart.save('self')
        context={'success':True}

        if form.is_valid():
            obj=form.save(commit=False)
            
            obj.save()
            form=OrderCreate()
            return redirect("products:order")
        return render(request,'index.html',{'product_list':product_list,'form':form})
# def Cart(request):
#     carts=Addcart.objects.all()
   
#     if request.method=='POST':
#         order_amount = int(request.POST.get("amount"))*100
#         client = razorpay.Client(auth=(RAZORPAY_API_KEY, RAZORPAY_API_SECRET_KEY))
#         order_currency = 'INR'
#         payment_order= client.order.create(dict(amount=order_amount, currency=order_currency, payment_capture=True ))
        
        
  
          
#     return render(request,'pay.html',{'api_key':RAZORPAY_API_KEY,'order_id':payment_order['id']})
       

class CartList(ListView):
    model=Addcart
    template_name='cart.html'
    context_object_name='carts'
    # client = razorpay.Client(auth=(RAZORPAY_API_KEY, RAZORPAY_API_SECRET_KEY))
    # order_amount=50000
    # order_currency = 'INR'
    # payment_order= client.order.create(dict(amount=order_amount, currency=order_currency, payment_capture=1 ))
    # payment_order_id=payment_order['id']
    # extra_context={'api_key':RAZORPAY_API_KEY,'order_id':payment_order_id}
   

    
class TodoDeleteView(DeleteView):
    model = Addcart
    template_name='delete.html'
    success_url = reverse_lazy("products:cart")

def order(request):
    cart=Addcart.objects.all()
    context={'cart':cart} 
    if request.method=='POST':
        name1=request.POST.get('name') 
        city=request.POST.get('city')
        zip=request.POST.get('zip')
        address=request.POST.get('address')
        phone=request.POST.get('phone')
        total=request.POST.get('total')
        items=request.POST.get('items')
        
        add=Order(name=name1,zip=zip,total=total,city=city,items=items,address=address,phone=phone)

        add.save('self')
        # context={'success':True}
        # return HttpResponse("You have successfully ordered your items")
        messages.success(request,"You have successfully ordered your items")
        return redirect("products:index")
    
    return render(request,'order.html',context)
   
#    if request.method == 'POST':
#         form = OrderCreate(request.POST)
#         if form.is_valid():
#             form.save()
        
#    else:
#       form = OrderCreate()
#    cart=Addcart.objects.all()
#    return render(request,'order.html',{'form':form,'cart':cart})

def Checkout(request):
    context={'success':False} 
    if request.method=='POST':
        title=request.POST.get('title') 
        price=request.POST.get('price')
        
        addcart=Addcart(title=title,price=price)

        addcart.save('self')
        context={'success':True}
        return redirect("products:order")
   
    return render(request,'index.html',context)