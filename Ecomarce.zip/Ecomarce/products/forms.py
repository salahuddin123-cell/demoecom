# from django.db import models
# from django.db.models import fields
# from django.forms.models import ALL_FIELDS
# from .models import Order
# from django import forms

# class OrderCreate(forms.ModelForm):
#     class Meta:
#         model=Order
#         fields=['name','adress','city','Zip','phone']